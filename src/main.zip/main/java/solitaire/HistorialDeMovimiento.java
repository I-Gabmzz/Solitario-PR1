package solitaire;

import DeckOfCards.CartaInglesa;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;


public class HistorialDeMovimiento {
    public String tipoMovimiento;
    public int origenTablero = -1;
    public int destinoTablero = -1;
    public int foundation = -1;
    public int cantidad = 0;
    public boolean volteo = false;
    public CartaInglesa carta;
    public ArrayList<CartaInglesa> cartas;
    private static final Deque<HistorialDeMovimiento> pila = new ArrayDeque<>();

    public static HistorialDeMovimiento draw(int n) {
        HistorialDeMovimiento movimiento = new HistorialDeMovimiento();
        movimiento.tipoMovimiento = "Mazo";
        movimiento.cantidad = n;
        return movimiento;
    }

    public static HistorialDeMovimiento recargar(int n) {
        HistorialDeMovimiento movimiento = new HistorialDeMovimiento();
        movimiento.tipoMovimiento = "Recarga";
        movimiento.cantidad = n;
        return movimiento;
    }

    public static HistorialDeMovimiento mazoAlTab(CartaInglesa carta, int alTablero) {
        HistorialDeMovimiento movimiento = new HistorialDeMovimiento();
        movimiento.tipoMovimiento = "MazoAlTab";
        movimiento.carta = carta;
        movimiento.destinoTablero = alTablero;
        return movimiento;
    }

    public static HistorialDeMovimiento mazoAlFound(CartaInglesa carta, int foundation) {
        HistorialDeMovimiento movimiento = new HistorialDeMovimiento();
        movimiento.tipoMovimiento = "MazoAlFound";
        movimiento.carta = carta;
        movimiento.foundation = foundation;
        return movimiento;
    }

    public static HistorialDeMovimiento tabAlTab(int origen, int destino, int n, boolean volteoAlSalir) {
        HistorialDeMovimiento movimiento = new HistorialDeMovimiento();
        movimiento.tipoMovimiento = "TabAlTab";
        movimiento.origenTablero = origen;
        movimiento.destinoTablero = destino;
        movimiento.cantidad = n;
        movimiento.volteo = volteoAlSalir;
        return movimiento;
    }

    public static HistorialDeMovimiento tabAlFound(int origen, int foundation, CartaInglesa carta, boolean volteoAlSalir) {
        HistorialDeMovimiento movimiento = new HistorialDeMovimiento();
        movimiento.tipoMovimiento = "TabAlFound";
        movimiento.origenTablero = origen;
        movimiento.foundation = foundation;
        movimiento.carta = carta;
        movimiento.volteo = volteoAlSalir;
        return movimiento;
    }

    public static void registrar(HistorialDeMovimiento mov) {
        pila.push(mov);
    }

    public static boolean puedeDeshacer() {
        return !pila.isEmpty();
    }

    public static boolean deshacer(DrawPile draw,
                                   WastePile waste,
                                   FoundationDeck[] foundations,
                                   TableauDeck[] tablero) {
        if (pila.isEmpty()) return false;

        HistorialDeMovimiento movimiento = pila.pop();

        switch (movimiento.tipoMovimiento) {
            case "Mazo": {
                ArrayList<CartaInglesa> devueltas = new ArrayList<>();
                for (int i = 0; i < movimiento.cantidad; i++) {
                    CartaInglesa c = waste.getCarta();
                    if (c != null) {
                        c.makeFaceDown();
                        devueltas.add(c);
                    }
                }
                draw.regresarDesdeWaste(devueltas);
                return true;
            }

            case "Recarga": {
                ArrayList<CartaInglesa> haciaWaste = draw.sacarParaWaste(movimiento.cantidad);
                if (!haciaWaste.isEmpty()) {
                    waste.addCartas(haciaWaste);
                }
                return true;
            }

            case "MazoAlTab": {
                TableauDeck t = tablero[movimiento.destinoTablero];
                CartaInglesa removida = t.removerUltimaCarta();
                if (removida != null) {
                    ArrayList<CartaInglesa> una = new ArrayList<>();
                    removida.makeFaceUp();
                    una.add(removida);
                    waste.addCartas(una);
                    return true;
                }
                return false;
            }

            case "MazoAlFound": {
                FoundationDeck found = foundations[movimiento.foundation];
                CartaInglesa removida = found.removerUltimaCarta();
                if (removida != null) {
                    ArrayList<CartaInglesa> cartas = new ArrayList<>();
                    removida.makeFaceUp();
                    cartas.add(removida);
                    waste.addCartas(cartas);
                    return true;
                }
                return false;
            }

            case "TabAlTab": {
                TableauDeck destino = tablero[movimiento.destinoTablero];
                TableauDeck origen = tablero[movimiento.origenTablero];
                ArrayList<CartaInglesa> bloque = destino.removerUltimasSinVoltear(movimiento.cantidad);
                if (movimiento.volteo) {
                    origen.voltearUltimaFaceDown();
                }
                if (!bloque.isEmpty()) {
                    origen.agregarBloqueDeCartasForzado(bloque);
                    return true;
                }
                return false;
            }


            case "TabAlFound": {
                FoundationDeck found = foundations[movimiento.foundation];
                CartaInglesa removida = found.removerUltimaCarta();
                if (removida != null) {
                    TableauDeck origen = tablero[movimiento.origenTablero];
                    if (movimiento.volteo) {
                        origen.voltearUltimaFaceDown();
                    }
                    origen.agregarCartaForzado(removida);
                    return true;
                }
                return false;
            }


        }
        return false;
    }
}
