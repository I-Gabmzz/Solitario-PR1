package Ejecutable;

import GUI.SolitaireTextUI;

public class SolitaireTests {
    public static void main(String[] args) {
        SolitaireTextUI sg = new SolitaireTextUI();

        sg.playGame();
    }
}